///////////////////////////////////////////////////////////////////
// XmlDocument.cpp - a container of XmlElement nodes   //
//                                                               //
// Application: Help for CSE687 Pr#2, Spring 2015                //
// Platform:    Dell XPS 2720, Win 8.1 Pro, Visual Studio 2013   //
// Author:      Jim Fawcett, CST 4-187, 443-3948                 //
//              jfawcett@twcny.rr.com                            //
///////////////////////////////////////////////////////////////////

#include <iostream>
#include "XmlDocument.h"

using namespace XmlProcessing;

XmlProcessing::XmlDocument::XmlDocument(const std::string& src, sourceType srcType)
{
  /* todo */
}

int main()
{
  title("Testing XmlDocument class");

  XmlDocument doc("foobar");

  std::cout << "\n\n";
}